package com.siteminder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiteminderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiteminderApplication.class, args);
	}

}
